# Minijuego — Escena 45: "El Derrumbe"

Minijuego de acción para el Capítulo IV, construido a partir del guion
de la Escena 45 (derrumbe de la cámara subterránea). Sigue el mismo
patrón arquitectónico que el resto de los minijuegos del proyecto: un
Web Component con Shadow DOM (`<derrumbe-final>`) + una Acción de
Monogatari (verbo `derrumbe`), ambos en un solo archivo,
`derrumbe-final.js`, cada uno en su propio IIFE.

## Archivos entregados

- `derrumbe-final.js` — el componente (canvas 2D, sin dependencia de
  fotos/assets externos, arte dibujado con formas vectoriales) y la
  Acción, en un solo archivo.
- `index-snippet.html` — las dos líneas a agregar en `index.html`
  (script + elemento).
- `escena45-snippet.js` — reemplazo sugerido del bloque `Escena45`
  completo (quita el `Choice` de proteger/escapar/salvar y lo
  reemplaza por la llamada al minijuego).
- Este archivo.

## Las 3 etapas (una sola sesión, un solo evento final)

Plataformero horizontal (estilo Mario / Mario Run): el jugador avanza
automáticamente, tiene una posición fija en pantalla y solo controla
el salto (espacio/↑/clic).

1. **Escapar del derrumbe** — corredor con rocas que caen del techo
   (con marca de impacto en el suelo antes de aterrizar) y grietas que
   se abren en el piso; hay que saltarlas a tiempo. 3 golpes = etapa
   fallida (se reintenta solo esa etapa, sin perder progreso).
2. **Salvar a Isidora** — primero hay que llegar hasta ella (el avance
   automático te acerca, saltando las rocas que sigan cayendo); al
   llegar comienza un QTE: mantener presionado o hacer clic
   repetidamente para llenar la barra de "levantar la roca" antes de
   que se acabe el tiempo, mientras siguen cayendo rocas sueltas (que
   también hay que saltar). Esta etapa es obligatoria — no existe una
   rama donde no se la rescate.
3. **Escapar y llegar a la cámara oculta** — versión más dura de la
   etapa 1 (más obstáculos, más rápido), con Isidora ya liberada
   corriendo como compañera visual detrás del jugador, saltando con un
   pequeño retraso cada vez que él salta. Al llegar al final se revela
   la cámara oculta y se muestra la pantalla de victoria.

Solo la pantalla de victoria dispara el evento final
`derrumbe:completado`, y el botón "Continuar" llama a `self.close()`
antes de dispararlo (para no repetir el bug histórico de otros
minijuegos del proyecto en los que el overlay se quedaba pegado sobre
la escena siguiente).

## Banderas de resultado

Antes de resolver la Acción, el componente informa el resultado vía
`CustomEvent('derrumbe:completado', { detail: { muroIntacto, isidoraSalvada } })`.
La propia Acción (`DerrumbeAction.apply()`) lee ese `detail` y lo deja
en `monogatari.storage()`:

- `derrumbeMuroIntacto` — `true` solo si la Etapa 1 se completó sin
  recibir ningún golpe. Reemplaza a la vieja rama "Proteger la
  estructura" del guion original: aquí no es una elección narrativa
  sino una recompensa por jugar limpio. `escena45-snippet.js` usa esta
  bandera para decidir si otorgar `mural_intacto`.
- `derrumbeIsidoraSalvada` — siempre `true` al llegar a este punto (la
  Etapa 2 es obligatoria). Se deja igual por si en el futuro se agrega
  alguna variante donde no lo sea; hoy `escena45-snippet.js` otorga
  `relacion_isidora_mejorada` sin condicionarla a esta bandera.

**Nota:** `monogatari.storage()` se usa asumiendo el mismo patrón
documentado para otros minijuegos del proyecto (mutar el objeto
devuelto directamente). Si tu build usa una API distinta para guardar
banderas de partida, el `try/catch` en `DerrumbeAction.apply()` evita
que un error ahí bloquee el avance del guion, pero conviene
confirmarlo contra tu `script.js` real antes de integrar.

## Gotchas del proyecto ya cubiertos

Repasados contra las lecciones documentadas de minijuegos anteriores:

- IIFE en ambos bloques (componente y Acción) — evita colisión de
  nombres globales como la de `epigrama-puzzle.js`/`vaticano-maze.js`.
- `resize()` del canvas se llama dentro de `open()`, no en el
  constructor — evita el bug de canvas 0×0 con `:host` en
  `display:none`.
- Los listeners de teclado están guardados con
  `self.hasAttribute('open')`, tanto en `keydown`/`keyup` como en el
  bucle de animación (`loop()` corta si el componente está cerrado).
- `stopPropagation` solo en `click`, no en otros eventos.
- Pantalla de victoria con un único botón "Continuar" (sin opción de
  repetir todo desde el principio).
- El botón "Continuar" llama a `self.close()` antes de disparar el
  evento de completado.
- Ningún elemento interno usa `z-index` propio — las 4 pantallas
  (`intro` / `fail` / `stage-clear` / `victory`) se alternan solo con
  una clase `.hidden` (`display:none`), evitando por diseño el tipo de
  bug de apilamiento que afectó al Altar (Escena 42) v4→v8.
- El Action extiende `Monogatari.Action` (namespace en mayúscula), usa
  `static id` como campo (no método), `static matchString([action])`,
  y el constructor destructura `[verb, elementId]` — mismo contrato
  confirmado en `laberinto-action.js`.

## Validación realizada

- `node --check derrumbe-final.js`: sin errores de sintaxis.
- Revisión manual completa de la lógica de juego contra el checklist
  de gotchas de arriba.

**Pendiente (no se pudo hacer en esta sesión):** no hubo acceso a un
navegador real ni al puente con tu computador para correr un
smoke test en Chromium con `monogatari.run('jump Escena45')` como sí
se hizo con `ruta7-race` o el Altar — ni una simulación de playthrough
en Node. Antes de dar esto por cerrado conviene probarlo a mano en tu
proyecto real (las 3 etapas, el reintento tras 3 golpes en cada una,
el QTE de rescate, y que "Continuar" en la pantalla final efectivamente
cierra el overlay y avanza el guion).

## Historial de correcciones tras integrarlo

- **v1 → v1.1**: el `<style>` del componente estaba definido (`STYLES`)
  pero nunca se insertaba dentro del `TEMPLATE` del Shadow DOM — por
  eso las 4 pantallas (intro/fallo/etapa-completada/victoria) no tenían
  `position:absolute` ni `display:none` y se veían todas apiladas al
  mismo tiempo, sin fondo ni color. Corregido agregando
  `<style>${STYLES}</style>` al `TEMPLATE.innerHTML`.
- **v1.1 → v1.2** (a pedido del usuario, tras probar la v1.1: "no se
  entiende, aparecen personajes que se mueven en forma horizontal, ni
  siquiera vertical, y si me quedo quieto el juego termina con éxito"):
  dos problemas reales de diseño, no solo de comunicación visual.
  1. Las rocas no caían: solo aparecían en el centro de la banda del
     jugador y crecían en el mismo punto (de ahí la sensación de
     "personajes" quietos moviéndose raro). Corregido con
     `obstaclePos()`: ahora una roca nace arriba de la pantalla y cae
     de verdad (con aceleración tipo gravedad) hasta la banda del
     jugador a lo largo de `TELEGRAPH_MS`, con una leve deriva
     horizontal propia — movimiento vertical y horizontal reales, no
     una mancha creciendo. El sprite de la roca también se cambió de
     dos círculos superpuestos (parecía una cara) a un polígono
     irregular tipo roca.
  2. El progreso de la etapa dependía solo del tiempo (auto-scroll):
     si ninguna roca caía exactamente sobre la posición del jugador,
     ganaba sin moverse. Corregido en `spawnObstacle()`: un 55% de las
     rocas ahora apunta cerca de la posición actual del jugador al
     generarse (con margen suficiente para reaccionar durante la
     caída), forzando a esquivar activamente en vez de poder quedarse
     quieto. La colisión también pasó de revisarse una sola vez en el
     instante del aterrizaje a revisarse continuamente mientras la
     roca cae y un instante después de aterrizar (escombro recién
     caído), vía `stepObstacles()`.

## v1.3 (versión actual) — más lento, rescate con clic, imágenes

A pedido del usuario tras probar la v1.2 ("está muy difícil, hacerlo
más lento; el rescate de Isidora debería ser con clic del mouse;
poner imágenes de fondo/rocas/personajes/grietas en la carpeta
images"):

1. **Ritmo más lento en las 3 etapas.** Se redujo `scrollSpeed` y
   `scrollAccel` de las 3 etapas (~35-40% más lento), se espaciaron los
   intervalos de aparición de obstáculos (`spawnMs`), se subió
   `TELEGRAPH_MS` de 700 a 1150 (casi el doble de tiempo de reacción
   desde que se ve la marca de impacto hasta que la roca realmente
   llega al suelo), se bajó la probabilidad de rocas "dirigidas" al
   jugador de 55% a 40% y se amplió el margen de puntería de esas rocas
   (de ~50px a ~140px) para que dejen más espacio real para esquivar.
   También se subió `INVULN_MS` (750→950) para dar un respiro mayor
   tras cada golpe. Todo esto son constantes al principio del archivo
   — si sigue sintiéndose muy rápido o muy lento, son los primeros
   números a tocar.
2. **Rescate con clic en vez de tecla.** La barra de "levantar la
   roca" de la Etapa 2 ya no se llena con ESPACIO: ahora se llena
   haciendo clic (o tocando en pantalla táctil) repetidamente sobre el
   canvas, o manteniendo el clic/toque presionado. El movimiento
   lateral para esquivar mientras dura el rescate sigue siendo con
   flechas/WASD.
3. **Carpeta `images/`.** El componente ahora intenta cargar 6
   archivos desde `images/` (junto a `derrumbe-final.js`, calculado
   automáticamente vía `document.currentScript`, así que funciona sin
   importar en qué carpeta del proyecto lo pongas):
   `muro.png`, `piso.png`, `roca.png`, `grieta.png`, `jugador.png`,
   `isidora.png`. Si un archivo no existe (o todavía no cargó), el
   juego sigue funcionando con el dibujo vectorial que ya tenía para
   esa pieza — nada se rompe por no tener alguna imagen puesta.

## v1.4 — más difícil por cantidad, no por velocidad

A pedido del usuario: se duplicó la cantidad de rocas y grietas que
aparecen en las etapas 1 y 3 (intervalo `spawnMs` a la mitad en ambas:
etapa 1 de `[1000,1500]` a `[500,750]`, etapa 3 de `[780,1150]` a
`[390,575]`), sin tocar `scrollSpeed`, `scrollAccel` ni `TELEGRAPH_MS`
— la velocidad de caída y de avance quedan igual que en la v1.3, solo
cae el doble de material. La Etapa 2 (rescate de Isidora) no se tocó.

## v1.5 — personajes más grandes, muros irregulares y más angostos

A pedido del usuario ("las imágenes de los protagonistas son muy
pequeñas, las paredes no son creíbles porque es una línea recta,
hacerlas más irregulares y disminuir el ancho"):

1. **Personajes más grandes.** El tamaño de dibujo del jugador, de
   Isidora (compañera y atrapada) pasó de `PLAYER_R*2.6 × PLAYER_R*3.6`
   a `PLAYER_R*4.4 × PLAYER_R*6.0` (~70% más grandes). El radio de
   colisión (`PLAYER_R`) no cambió — es solo el tamaño visual del
   sprite, no la "hitbox".
2. **Muros irregulares y más angostos.** Antes el borde entre el
   camino y la pared era una línea vertical recta fija
   (`laneLeft`/`laneRight` a 6%/94% del ancho). Ahora es un contorno
   ondulado (`corridorEdges()`, suma de 3 senos con distinta frecuencia,
   desplazándose con `worldY` para sentirse parte del túnel en
   movimiento) y el muro base ocupa menos ancho (4.5%/95.5% en vez de
   6%/94%, dejando más camino disponible). El jugador y la compañera
   ahora respetan ese mismo contorno al moverse (`playerBoundsNorm()`
   calcula el límite real en la fila donde está el jugador, en vez de
   un número fijo) — así nunca atraviesan visualmente una pared que
   ahora es angosta.

## v2.0 — de juego vertical a plataformero horizontal (estilo Mario)

Cambio de fondo pedido por el usuario: "en vez de ser un juego
vertical, que sea horizontal, como el de Mario Bros; el jugador debe
avanzar y saltar las grietas que se van creando y esquivar las rocas;
ahora las paredes están al fondo del juego y bajo los pies de los
jugadores es el piso". Se reescribió toda la física y el control del
minijuego (las 3 etapas conservan la misma estructura y las mismas
banderas de resultado, `derrumbeMuroIntacto` / `derrumbeIsidoraSalvada`):

- **El jugador ya no se mueve lateralmente.** Tiene una posición fija
  en pantalla (24% desde la izquierda) y solo controla el salto —
  ESPACIO, flecha arriba, W, o un toque/clic sobre el juego. El
  "avance" ahora lo hace el mundo (desplazamiento horizontal
  automático), no el sprite: es el propio jugador el que corre hacia
  la derecha en la lógica del juego, aunque en pantalla se vea el
  entorno pasando bajo sus pies (igual que Mario Run o cualquier
  runner automático).
- **Grietas**: ahora son huecos reales en el piso con un ancho
  calculado a partir de cuánto avanza el jugador durante el arco de un
  salto (`scrollSpeed × tiempo en el aire`), para que sean saltables
  con buen timing pero no automáticas. Si el jugador está sobre el
  hueco y no saltó lo suficientemente alto (`player.y <
  CRACK_CLEAR_HEIGHT`), pierde una vida.
- **Rocas**: siguen cayendo del techo con la misma animación de caída
  y marca de impacto en el suelo que ya tenían, pero ahora aparecen
  bien por delante (fuera de pantalla, a la derecha) y se acercan por
  el avance horizontal — para cuando llegan a la posición del jugador
  normalmente ya llevan un rato en el suelo, así que se leen como un
  obstáculo real que hay que saltar, no como un impacto sorpresa.
- **Muros al fondo, piso bajo los pies.** El muro (`images/muro.png`)
  ahora se dibuja como una capa de fondo con parallax (se desplaza a
  0.35× la velocidad del piso, dando sensación de profundidad) en vez
  de flanquear los costados del camino. El piso (`images/piso.png`) se
  desplaza 1:1 bajo los pies del jugador, horizontalmente.
- **Etapa 2 (rescate) sin cambios de fondo**: sigue siendo llegar
  hasta Isidora y llenar la barra a clic/toque, salvo que ahora,
  durante ese tramo (el avance se congela mientras dura el rescate),
  las rocas caen en puntos fijos de la pantalla en vez de acercarse
  por el track — el jugador puede seguir saltándolas mientras clickea
  para levantar la roca.
- **Isidora en la Etapa 3** ya no sigue al jugador copiando su
  posición con retraso (eso era del juego lateral): ahora salta con un
  pequeño retraso (`COMPANION_JUMP_DELAY_MS`) cada vez que el jugador
  salta, replicando sus saltos un poco después — el efecto visual de
  "va corriendo justo detrás tuyo, saltando lo mismo que tú".

**Sin probar en navegador real todavía** (mismo límite que en
iteraciones anteriores: sin Chromium ni puente al computador en esta
sesión) — solo `node --check` y revisión manual de la física. Vale la
pena jugarlo a fondo antes de darlo por cerrado, en particular el
timing de los saltos sobre las grietas.

## v2.1 — movimiento adelante/atrás, y arregla el bloqueo de la etapa 1

A pedido del usuario tras probar la v2.0 ("el personaje debería ir
para adelante y atrás; las rocas/grietas que van quedando no dejan
terminar la etapa 1, hay demasiadas"):

1. **Movimiento adelante/atrás.** Flechas izquierda/derecha (o A/D)
   ahora adelantan o retrasan al jugador dentro de un rango acotado
   (`playerOffsetX`, hasta ~30% del ancho de pantalla adelante y ~10%
   atrás). No es un cambio de carril (el juego sigue siendo de un solo
   plano, como Mario) sino una forma de afinar el timing: adelantarte
   un poco te hace cruzar antes el punto exacto de una grieta o roca,
   atrasarte te da un respiro extra antes de llegar a ella. El salto
   (ESPACIO/↑/clic) sigue siendo lo único que realmente esquiva un
   obstáculo; el adelante/atrás es un ajuste fino de cuándo llegas a
   él, no un carril alternativo.
2. **Bug real corregido: obstáculos apilados imposibles de saltar.**
   La verdadera causa de que la etapa 1 no se pudiera terminar no era
   solo la cantidad — con `spawnMs` muy corto (de un pedido anterior de
   "duplicar la cantidad"), dos obstáculos podían generarse con
   posiciones tan cercanas en el mundo que sus zonas de peligro se
   superponían: no había forma física de saltar ambos a la vez.
   Corregido con una separación mínima real entre obstáculos
   consecutivos (`MIN_OBSTACLE_GAP_PX`): cada obstáculo nuevo se
   empuja hacia adelante si quedaría más cerca del anterior de lo que
   un salto puede resolver. De paso se bajó la frecuencia de aparición
   en las etapas 1 y 3 (que se habían duplicado en una iteración
   anterior a pedido del usuario) a un ritmo que un jugador humano
   puede sostener saltando uno por uno.

## v2.2 — rocas que caen de verdad al acercarse, grietas que cortan todo el piso

A pedido del usuario tras probar la v2.1 ("las rocas deberían caer
mientras el jugador está pasando; las grietas no se ven reales,
deberían estar dibujadas sobre todo el piso"):

1. **Caída de la roca atada a la distancia, no al reloj.** Antes una
   roca terminaba de caer `FALL_MS` (0.9s) después de generarse — como
   se generan bien por delante y tardan varios segundos en llegar, para
   cuando el jugador las alcanzaba ya llevaban rato quietas en el
   suelo. Ahora (`rockFallT()`) el progreso de caída depende de qué tan
   cerca está la roca del jugador: se mantiene arriba, en el aire,
   mientras está lejos, y cae de verdad recién al entrar en una
   "zona de caída" (`FALL_ZONE_PX`, 260px) cerca de la posición del
   jugador — el aterrizaje coincide con el momento en que realmente hay
   que saltarla. Las rocas "congeladas" del rescate (etapa 2) siguen
   cayendo con el reloj, porque ahí no hay una distancia de la que
   depender (el mundo no avanza durante el QTE).
2. **Grietas que cortan todo el piso.** Antes se dibujaban como una
   marca delgada pegada a la línea del suelo. Ahora la grieta es un
   vacío real que va de borde a borde del piso (desde la línea de
   suelo hasta el fondo del canvas), con un contorno superior
   irregular (generado una sola vez por grieta, para que no titile de
   cuadro en cuadro) y un resplandor cálido en el interior — se lee
   como un corte real en el terreno, no como una mancha en la
   superficie.

## v2.3 — caída continua desde arriba, más densidad, nuevo prompt de grieta

A pedido del usuario tras probar la v2.2:

1. **Las rocas ya no "flotan y después caen".** Antes se mantenían
   quietas a una altura fija (8% de la pantalla) mientras se acercaban
   por el track, y solo caían de verdad en los últimos 260px antes de
   llegar al jugador. Ahora (`rockFallT()` usa `o.spawnOffset`, la
   distancia que tenían que recorrer al generarse, en vez de una zona
   fija) caen de forma continua durante TODO su recorrido visible:
   aparecen arriba de la ventana del navegador (`ROCK_SKY_Y = -40`, por
   encima del borde superior del canvas, no a un 8% fijo de la
   pantalla) y van bajando a medida que se acercan, aterrizando justo
   cuando llegan a la posición del jugador.
2. **Más cantidad en las 3 etapas** (antes solo se había duplicado en
   las etapas 1 y 3): se volvió a acortar `spawnMs` a la mitad también
   en la Etapa 2. Como la separación mínima real entre obstáculos
   (`MIN_OBSTACLE_GAP_PX`, de la corrección anterior) sigue vigente,
   esto en la práctica genera obstáculos al ritmo máximo que todavía se
   puede saltar uno por uno — más denso y con rocas visibles en
   distintos puntos de su caída al mismo tiempo, pero sin volver a
   producir combinaciones imposibles de saltar.
3. **Nuevo prompt para `grieta.png`** (ver más abajo, sección Arte): el
   prompt anterior pedía una vista cenital (de cuando el juego era
   vertical); el juego ahora es de perfil, así que se reemplazó por uno
   que pide una grieta/precipicio visto de costado, abierto hacia
   abajo.

## Arte

**Importante:** en este entorno no tengo generación de imágenes con
IA disponible (ni acceso a Midjourney/DALL·E/Stable Diffusion como en
tu flujo habitual). Lo que incluye el ZIP en `images/` son 6
imágenes **generadas de forma procedural con Python/Pillow** —
formas geométricas y texturas de ruido con la misma paleta de color
que ya tenía el minijuego, pensadas para que el juego se vea con
imágenes reales desde ya (piso y muro son texturas tileable de
verdad, sin costuras) y no como un simple placeholder de color plano.
No son arte fotorrealista ni están hechas por un modelo generativo:

- `piso.png`, `muro.png` — 256×256, tileable (`ctx.createPattern`).
- `roca.png` — 220×220, con transparencia.
- `grieta.png` — 340×150, con transparencia.
- `jugador.png`, `isidora.png` — 160×220, con transparencia, siluetas
  simples (teal vs. terracota, con cola de caballo para diferenciar a
  Isidora).

Si más adelante quieres arte hiperrealista de verdad (mismo pipeline
que `ruta7-carretera-austral`: fotos con fondo blanco → recorte con
Python/scipy → `data:` URI o archivo en `images/`), estos son los
prompts en español que puedes usar en Midjourney/DALL·E/Stable
Diffusion — el nombre de archivo final debe ser el mismo (para
reemplazar el placeholder sin tocar el código):

- **`piso.png`** — "Textura de piso de tierra y grava de una cueva
  subterránea, vista cenital, iluminación tenue y polvorienta, tonos
  marrón oscuro, fotografía hiperrealista, sin personajes, textura
  repetible sin costuras."
- **`muro.png`** — "Textura de pared de roca de una caverna
  subterránea, estratos de piedra irregular, humedad y vetas
  minerales, iluminación tenue lateral, fotografía hiperrealista, sin
  personajes, textura repetible sin costuras."
- **`roca.png`** — "Una sola roca desprendida de tamaño mediano,
  fondo blanco liso, iluminación de estudio, fotografía
  hiperrealista, superficie irregular con fracturas visibles, vista
  de tres cuartos."
- **`grieta.png`** (actualizado — el juego ahora es de perfil, no
  cenital) — "Precipicio o grieta abierta en el piso de roca de una
  caverna, vista de perfil (lateral), como para un videojuego de
  plataformas 2D: un corte vertical que atraviesa todo el piso, con el
  borde superior irregular y fracturado, abriéndose hacia abajo hacia
  la oscuridad total, un tenue resplandor anaranjado saliendo desde el
  fondo del abismo, fondo transparente, orientación vertical (más alta
  que ancha), fotografía hiperrealista, sin personajes."
- **`jugador.png`** — "Personaje aventurero corriendo en pose
  dinámica, vista de tres cuartos, ropa de expedición color verde
  azulado, fondo blanco liso, iluminación de estudio, fotografía
  hiperrealista, cuerpo completo."
- **`isidora.png`** — "Personaje femenino, Isidora, corriendo en pose
  dinámica, cabello atado en cola de caballo, ropa de expedición color
  terracota, fondo blanco liso, iluminación de estudio, fotografía
  hiperrealista, cuerpo completo."

Como con `ruta7-carretera-austral`, una vez generadas las fotos reales
avísame para preparar el recorte de fondo (Python + scipy/numpy) antes
de dejarlas en `images/`.
